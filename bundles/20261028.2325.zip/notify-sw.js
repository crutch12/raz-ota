// Service worker уведомлений. Classic-скрипт без импортов, подключается через importScripts.
// SW единственный писатель очереди событий, страница только читает и шлёт ack
(function () {
  var CACHE = 'raznos-notify';
  var PENDING = '/__raznos-notify/pending';
  var CATEGORIES = '/__raznos-notify/categories';
  var DISABLED = '/__raznos-notify/disabled';
  var SCHEDULED = '/__raznos-notify/scheduled';
  var TRACK_CFG = '/__raznos-notify/tracking';
  var TRACK_QUEUE = '/__raznos-notify/track-queue';
  var TRACK_DEVICE = '/__raznos-notify/device-id';
  var REGISTER_CFG = '/__raznos-notify/register';
  var REGISTER_TOKEN = '/__raznos-notify/register-token';
  var REGISTER_QUEUE = '/__raznos-notify/register-queue';
  var LOCALE = '/__raznos-notify/locale';
  var FLUSH_TAG = 'raznos-notify-flush';
  var SILENT_TAG = 'raznos-silent';
  var MAX_QUEUE = 100;
  // просроченные дольше выбрасываем, а не показываем
  var MAX_OVERDUE_MS = 24 * 60 * 60 * 1000;
  // столько держим SW живым ради ближайшей записи, дальше ждём следующего пробуждения
  var HOLD_MS = 2 * 60 * 1000;
  // трекинг: очередь до 500 событий, пачка уходит через ~2 с после события, повторы 5 с, 30 с, 5 мин
  var MAX_TRACK_QUEUE = 500;
  var TRACK_BATCH = 100;
  var TRACK_DEBOUNCE_MS = typeof self.raznosTrackDebounceMs === 'number' ? self.raznosTrackDebounceMs : 2000;
  var TRACK_RETRY_MS = Array.isArray(self.raznosTrackRetryMs) ? self.raznosTrackRetryMs : [5000, 30000, 5 * 60 * 1000];
  var TRACK_TIMEOUT_MS = 10000;
  // registerUrl: в очереди только последний токен, повторы как у трекинга
  var REGISTER_RETRY_MS = Array.isArray(self.raznosRegisterRetryMs) ? self.raznosRegisterRetryMs : [5000, 30000, 5 * 60 * 1000];
  var TRACK_TYPES = { received: 'delivered', opened: 'opened', action: 'action', dismissed: 'dismissed' };

  function readJson(key, fallback) {
    return self.caches
      .open(CACHE)
      .then(function (c) {
        return c.match(key);
      })
      .then(function (r) {
        return r ? r.json() : fallback;
      })
      .catch(function () {
        return fallback;
      });
  }

  function writeJson(key, value) {
    return self.caches.open(CACHE).then(function (c) {
      return c.put(key, new Response(JSON.stringify(value), { headers: { 'content-type': 'application/json' } }));
    });
  }

  // записи в очередь идут строго по одной, иначе read-modify-write теряет события
  var queueChain = Promise.resolve();
  function updateQueue(fn) {
    var next = queueChain.then(function () {
      return readJson(PENDING, []).then(function (list) {
        return writeJson(PENDING, fn(list));
      });
    });
    queueChain = next.catch(function () {});
    return next;
  }

  // запланированные: [{ key, at, payload, source }], тоже по одной записи за раз
  var schedChain = Promise.resolve();
  function updateScheduled(fn) {
    var next = schedChain.then(function () {
      return readJson(SCHEDULED, []).then(function (list) {
        var res = fn(list);
        return writeJson(SCHEDULED, res.list).then(function () {
          return res.out;
        });
      });
    });
    schedChain = next.catch(function () {});
    return next;
  }

  function addScheduled(payload, at, source) {
    var key = keyOf(payload);
    return updateScheduled(function (list) {
      var rest = list.filter(function (e) {
        return e.key !== key;
      });
      rest.push({ key: key, at: at, payload: payload, source: source });
      return { list: rest };
    });
  }

  // ключ записи (tag/id) или messageId её payload. messageOnly: только по messageId (для replaces)
  function matchesKey(key, payload, keys, messageOnly) {
    var byMessage = Boolean(payload && payload.messageId) && keys.indexOf(payload.messageId) >= 0;
    return byMessage || (!messageOnly && keys.indexOf(key) >= 0);
  }

  // отдаёт число убранных записей
  function removeScheduled(keys, messageOnly) {
    return updateScheduled(function (list) {
      var kept = list.filter(function (e) {
        return !matchesKey(e.key, e.payload, keys, messageOnly);
      });
      return { list: kept, out: list.length - kept.length };
    });
  }

  // закрывает показанные по tag или messageId, отдаёт число закрытых
  function closeShown(keys, messageOnly) {
    return self.registration.getNotifications().then(function (list) {
      var closed = 0;
      list.forEach(function (n) {
        var data = n.data && n.data.raznos;
        if (matchesKey(n.tag, data, keys, messageOnly)) {
          n.close();
          closed++;
        }
      });
      return closed;
    });
  }

  // снимает показанные и отложенные, отдаёт сколько всего снято
  function cancelKeys(keys, messageOnly) {
    return Promise.all([closeShown(keys, messageOnly), removeScheduled(keys, messageOnly)]).then(function (r) {
      return r[0] + r[1];
    });
  }

  // Chrome требует показ на каждый push (userVisibleOnly). Если после отмены ничего не осталось,
  // показываем тихое уведомление и сразу закрываем
  function showSilentPlaceholder() {
    return self.registration.getNotifications().then(function (list) {
      var left = list.filter(function (n) {
        return n.tag !== SILENT_TAG;
      });
      if (left.length > 0) return;
      return self.registration
        .showNotification('', { tag: SILENT_TAG, silent: true })
        .then(function () {
          return self.registration.getNotifications({ tag: SILENT_TAG });
        })
        .then(function (shown) {
          shown.forEach(function (n) {
            n.close();
          });
        });
    });
  }

  // забирает просроченные из хранилища одним шагом: кто забрал, тот и показывает, поэтому дублей нет
  function flushDue() {
    return updateScheduled(function (list) {
      var now = Date.now();
      var due = [];
      var future = [];
      list.forEach(function (e) {
        if (e.at > now) future.push(e);
        else if (now - e.at <= MAX_OVERDUE_MS) due.push(e);
      });
      return { list: future, out: { due: due, future: future } };
    }).then(function (res) {
      return Promise.all(
        res.due.map(function (e) {
          return display(e.payload, e.source).catch(function () {});
        })
      ).then(function () {
        return res.future;
      });
    });
  }

  // показывает просроченное и держит SW, пока ближайшая запись не дальше HOLD_MS
  function runScheduled() {
    return flushDue().then(function (future) {
      var next = future.reduce(function (m, e) {
        return m === null || e.at < m ? e.at : m;
      }, null);
      if (next === null) return;
      var wait = Math.max(0, next - Date.now());
      if (wait > HOLD_MS) return;
      return new Promise(function (resolve) {
        setTimeout(resolve, wait);
      }).then(runScheduled);
    });
  }

  // любое пробуждение: показываем просроченное и досылаем трекинг
  function run() {
    return Promise.all([runScheduled(), trackKick(), registerKick()]);
  }

  // очередь трекинга пишется по одной записи за раз, как и основная
  var trackChain = Promise.resolve();
  function updateTrackQueue(fn) {
    var next = trackChain.then(function () {
      return readJson(TRACK_QUEUE, []).then(function (list) {
        return writeJson(TRACK_QUEUE, fn(list));
      });
    });
    trackChain = next.catch(function () {});
    return next;
  }

  var devicePromise = null;
  function ensureDeviceId() {
    devicePromise =
      devicePromise ||
      readJson(TRACK_DEVICE, null).then(function (id) {
        if (typeof id === 'string' && id) return id;
        var fresh = newId();
        return writeJson(TRACK_DEVICE, fresh).then(function () {
          return fresh;
        });
      });
    return devicePromise;
  }

  var trackTimer = null;
  // держит SW живым от события до конца отправки, повторы по таймеру его не держат
  var trackHold = null;
  var trackBusy = null;
  var trackFailures = 0;

  function trackSchedule(delay, hold) {
    if (trackTimer) clearTimeout(trackTimer);
    if (hold && !trackHold) {
      var h = {};
      h.promise = new Promise(function (resolve) {
        h.resolve = resolve;
      });
      trackHold = h;
    }
    trackTimer = setTimeout(function () {
      trackTimer = null;
      var taken = trackHold;
      trackHold = null;
      var done = function () {
        if (taken) taken.resolve();
      };
      trackFlush().then(done, done);
    }, delay);
  }

  function trackIdle() {
    return Promise.all([trackHold ? trackHold.promise : null, trackBusy]);
  }

  function trackFlush() {
    trackBusy = (trackBusy || Promise.resolve()).then(sendBatch).catch(function () {});
    return trackBusy;
  }

  function post(cfg, device, batch) {
    var headers = { 'content-type': 'application/json' };
    Object.keys(cfg.headers || {}).forEach(function (k) {
      headers[k] = cfg.headers[k];
    });
    var timer;
    var timeout = new Promise(function (resolve) {
      timer = setTimeout(function () {
        resolve(false);
      }, TRACK_TIMEOUT_MS);
    });
    var request = self
      .fetch(cfg.url, {
        method: 'POST',
        keepalive: true,
        headers: headers,
        body: JSON.stringify({ deviceId: device, platform: 'web', events: batch }),
      })
      .then(
        function (r) {
          return r.ok;
        },
        function () {
          return false;
        }
      );
    return Promise.race([request, timeout]).then(function (ok) {
      clearTimeout(timer);
      return ok;
    });
  }

  function sendBatch() {
    return Promise.all([readJson(TRACK_CFG, null), readJson(TRACK_QUEUE, [])]).then(function (res) {
      var cfg = res[0];
      var batch = res[1].slice(0, TRACK_BATCH);
      if (!cfg || !cfg.url || batch.length === 0) return;
      return ensureDeviceId()
        .then(function (device) {
          return post(cfg, device, batch);
        })
        .then(function (ok) {
          if (!ok) {
            if (trackFailures < TRACK_RETRY_MS.length) trackSchedule(TRACK_RETRY_MS[trackFailures++], false);
            // после трёх неудач ждём следующего события или пробуждения
            return;
          }
          trackFailures = 0;
          var sent = batch.map(function (e) {
            return e.eventId;
          });
          return updateTrackQueue(function (list) {
            return list.filter(function (e) {
              return sent.indexOf(e.eventId) < 0;
            });
          }).then(function () {
            return readJson(TRACK_QUEUE, []).then(function (rest) {
              if (rest.length > 0) trackSchedule(0, true);
            });
          });
        });
    });
  }

  // пробуждение: сбрасываем счётчик ошибок и досылаем накопленное
  function trackKick() {
    return Promise.all([readJson(TRACK_CFG, null), readJson(TRACK_QUEUE, [])]).then(function (res) {
      if (res[0] && res[0].url && res[1].length > 0 && !trackTimer) {
        trackFailures = 0;
        trackSchedule(0, true);
      }
      return trackIdle();
    });
  }

  // ответ приёмника: ok, final (4xx кроме 408 и 429, повтор не нужен) или retry
  function postJson(url, headers, body) {
    var h = { 'content-type': 'application/json' };
    Object.keys(headers || {}).forEach(function (k) {
      h[k] = headers[k];
    });
    var timer;
    var timeout = new Promise(function (resolve) {
      timer = setTimeout(function () {
        resolve('retry');
      }, TRACK_TIMEOUT_MS);
    });
    var request = self.fetch(url, { method: 'POST', keepalive: true, headers: h, body: JSON.stringify(body) }).then(
      function (r) {
        if (r.ok) return 'ok';
        return r.status >= 400 && r.status < 500 && r.status !== 408 && r.status !== 429 ? 'final' : 'retry';
      },
      function () {
        return 'retry';
      }
    );
    return Promise.race([request, timeout]).then(function (res) {
      clearTimeout(timer);
      return res;
    });
  }

  // очередь регистрации: { register?, unregister? }, пишется по одной записи за раз
  var regChain = Promise.resolve();
  function updateRegQueue(fn) {
    var next = regChain.then(function () {
      return readJson(REGISTER_QUEUE, {}).then(function (q) {
        return writeJson(REGISTER_QUEUE, fn(q));
      });
    });
    regChain = next.catch(function () {});
    return next;
  }

  var regTimer = null;
  var regBusy = Promise.resolve();
  var regFailures = 0;

  function regSchedule(delay) {
    if (regTimer) clearTimeout(regTimer);
    regTimer = setTimeout(function () {
      regTimer = null;
      regFlush();
    }, delay);
  }

  function regFlush() {
    regBusy = regBusy.then(sendRegister).catch(function () {});
    return regBusy;
  }

  // отправляет записи по одной, при retry останавливается и ставит повтор
  function sendRegister() {
    return Promise.all([readJson(REGISTER_CFG, null), readJson(REGISTER_QUEUE, {})]).then(function (res) {
      var cfg = res[0];
      var queue = res[1];
      if (!cfg || !cfg.url) return;
      var kinds = ['unregister', 'register'].filter(function (k) {
        return queue[k] && (k === 'register' ? cfg.url : cfg.unregisterUrl);
      });
      return kinds.reduce(function (chain, kind) {
        return chain.then(function (stop) {
          if (stop) return stop;
          var entry = queue[kind];
          return postJson(kind === 'register' ? cfg.url : cfg.unregisterUrl, cfg.headers, entry).then(function (result) {
            if (result === 'retry') {
              if (regFailures < REGISTER_RETRY_MS.length) regSchedule(REGISTER_RETRY_MS[regFailures++]);
              return true;
            }
            regFailures = 0;
            // запись могли заменить новым токеном, пока шёл запрос: убираем только ту, что отправили
            return updateRegQueue(function (q) {
              if (q[kind] && q[kind].eventId === entry.eventId) delete q[kind];
              return q;
            }).then(function () {
              return false;
            });
          });
        });
      }, Promise.resolve(false));
    });
  }

  // пробуждение: сбрасываем счётчик ошибок и досылаем накопленное
  function registerKick() {
    return Promise.all([readJson(REGISTER_CFG, null), readJson(REGISTER_QUEUE, {})]).then(function (res) {
      if (res[0] && res[0].url && (res[1].register || res[1].unregister) && !regTimer) {
        regFailures = 0;
        return regFlush();
      }
    });
  }

  function timezone() {
    try {
      return Intl.DateTimeFormat().resolvedOptions().timeZone;
    } catch {
      return undefined;
    }
  }

  function regBody(cfg, device, transport, token, locale) {
    var body = { eventId: newId(), deviceId: device, platform: 'web', transport: transport, token: token };
    if (locale) body.locale = locale;
    var tz = timezone();
    if (tz) body.timezone = tz;
    body.at = Date.now();
    body.extra = cfg.extra || {};
    return body;
  }

  // ставит токен в очередь (заменяя прежний) и отправляет. Без включённого registerUrl только запоминает токен
  function enqueueRegister(transport, token) {
    return Promise.all([readJson(REGISTER_CFG, null), currentLocale(), ensureDeviceId()]).then(function (res) {
      var cfg = res[0];
      return writeJson(REGISTER_TOKEN, { transport: transport, token: token }).then(function () {
        if (!cfg || !cfg.url) return;
        var body = regBody(cfg, res[2], transport, token, res[1]);
        return updateRegQueue(function (q) {
          q.register = body;
          delete q.unregister;
          return q;
        }).then(function () {
          regFailures = 0;
          return regFlush();
        });
      });
    });
  }

  // отписка: unregisterUrl с токеном, сохранённый токен и неотправленная регистрация сбрасываются
  function enqueueUnregister(transport, token) {
    return Promise.all([readJson(REGISTER_CFG, null), readJson(REGISTER_TOKEN, null), ensureDeviceId()]).then(function (res) {
      var cfg = res[0];
      var saved = res[1];
      var tok = token || (saved && saved.token);
      var tr = transport || (saved && saved.transport) || 'webpush';
      return writeJson(REGISTER_TOKEN, null).then(function () {
        return updateRegQueue(function (q) {
          delete q.register;
          if (cfg && cfg.url && cfg.unregisterUrl && tok) q.unregister = regBody(cfg, res[2], tr, tok, '');
          return q;
        }).then(function () {
          regFailures = 0;
          return regFlush();
        });
      });
    });
  }

  // конфиг поменялся: пересылаем текущий токен с новым extra, выключенный убирает неотправленное
  function onRegisterConfig() {
    return Promise.all([readJson(REGISTER_CFG, null), readJson(REGISTER_TOKEN, null)]).then(function (res) {
      if (!res[0] || !res[0].url) {
        return updateRegQueue(function (q) {
          delete q.register;
          return q;
        });
      }
      if (res[1] && res[1].token) return enqueueRegister(res[1].transport, res[1].token);
      return self.registration.pushManager.getSubscription().then(function (sub) {
        if (sub) return enqueueRegister('webpush', JSON.stringify(sub.toJSON()));
      });
    });
  }

  // браузер сменил подписку: подписываемся заново тем же ключом и шлём новую на registerUrl
  function onSubscriptionChange(event) {
    var old = event.oldSubscription;
    var fresh = event.newSubscription
      ? Promise.resolve(event.newSubscription)
      : old && old.options
        ? self.registration.pushManager
            .subscribe({ userVisibleOnly: true, applicationServerKey: old.options.applicationServerKey })
            .catch(function () {
              return null;
            })
        : self.registration.pushManager.getSubscription();
    return fresh.then(function (sub) {
      if (sub) return enqueueRegister('webpush', JSON.stringify(sub.toJSON()));
    });
  }

  // в трекинг идут только события с messageId и только при включённой настройке
  function track(event) {
    var messageId = event.notification && event.notification.messageId;
    var type = TRACK_TYPES[event.type];
    if (typeof messageId !== 'string' || !messageId || !type) return Promise.resolve();
    return readJson(TRACK_CFG, null).then(function (cfg) {
      if (!cfg || !cfg.url) return;
      var t = { eventId: event.eventId, messageId: messageId, type: type };
      if (event.actionId) t.actionId = event.actionId;
      if (event.inputText && cfg.includeInput === true) t.inputText = event.inputText;
      if (event.notification.category) t.category = event.notification.category;
      t.at = event.at;
      t.source = event.source;
      return updateTrackQueue(function (list) {
        list.push(t);
        return list.slice(-MAX_TRACK_QUEUE);
      }).then(function () {
        trackSchedule(TRACK_DEBOUNCE_MS, true);
      });
    });
  }

  function keyOf(p) {
    return p.tag || p.id;
  }

  function norm(s) {
    return String(s).toLowerCase().replace(/_/g, '-');
  }

  // значение для языка: точный язык, язык без региона, default. isValid отсеивает пустое и не того типа
  function lookup(loc, locale, isValid) {
    if (!loc || typeof loc !== 'object') return undefined;
    var map = {};
    Object.keys(loc).forEach(function (k) {
      map[norm(k)] = loc[k];
    });
    var full = locale ? norm(locale) : '';
    var keys = full ? [full, full.split('-')[0], 'default'] : ['default'];
    for (var i = 0; i < keys.length; i++) {
      if (isValid(map[keys[i]])) return map[keys[i]];
    }
    return undefined;
  }

  // точный язык, язык без региона, default, обычное поле (тот же порядок, что у resolveLocalized в JS)
  function pick(loc, locale, fallback) {
    var found = lookup(loc, locale, function (v) {
      return typeof v === 'string' && v !== '';
    });
    return found === undefined ? fallback : found;
  }

  // то же для массива строк (appearance.lines_loc)
  function pickLines(loc, locale, fallback) {
    var found = lookup(loc, locale, function (v) {
      return Array.isArray(v) && v.length > 0;
    });
    return found === undefined ? fallback : found;
  }

  // язык, выбранный в приложении, иначе язык устройства
  function currentLocale() {
    return readJson(LOCALE, '').then(function (l) {
      return l || (typeof self.navigator === 'object' && self.navigator ? self.navigator.language : '') || '';
    });
  }

  // запись набора категорий, страница пишет туда же, поэтому читаем заново
  var catChain = Promise.resolve();
  function updateCategories(fn) {
    var next = catChain.then(function () {
      return readJson(CATEGORIES, []).then(function (list) {
        var res = fn(list);
        return writeJson(CATEGORIES, res).then(function () {
          return res;
        });
      });
    });
    catChain = next.catch(function () {});
    return next;
  }

  function upsertCategory(def) {
    return updateCategories(function (list) {
      var found = false;
      var out = list.map(function (c) {
        if (c.id !== def.id) return c;
        found = true;
        return def;
      });
      if (!found) out.push(def);
      return out;
    });
  }

  function newId() {
    return self.crypto.randomUUID();
  }

  function findAction(payload, categories, actionId) {
    var list = payload.actions;
    if (!list) {
      var cat = categories.filter(function (c) {
        return c.id === payload.category;
      })[0];
      list = (cat && cat.actions) || [];
    }
    return list.filter(function (a) {
      return a.id === actionId;
    })[0];
  }

  function buildOptions(payload, source, categories, locale) {
    var list = payload.actions;
    if (!list) {
      var cat = categories.filter(function (c) {
        return c.id === payload.category;
      })[0];
      list = (cat && cat.actions) || [];
    }
    var max = (self.Notification && self.Notification.maxActions) || 0;
    var actions = list.slice(0, max).map(function (a) {
      return { action: a.id, title: pick(a.title_loc, locale, a.title) };
    });
    var ap = payload.appearance || {};
    var body = pick(payload.body_loc, locale, payload.body);
    var lines = pickLines(ap.lines_loc, locale, ap.lines);
    if ((ap.style === 'inbox' || ap.style === 'messaging') && lines && lines.length) {
      body = lines.join('\n');
    }
    var options = {
      body: body,
      tag: keyOf(payload),
      silent: payload.silent === true,
      data: { raznos: payload, source: source },
      actions: actions,
    };
    if (ap.image) options.image = ap.image;
    if (ap.largeIcon) options.icon = ap.largeIcon;
    return options;
  }

  // сфокусированное окно, иначе первое
  function pickClient(list) {
    return list.filter(function (c) {
      return c.focused;
    })[0] || list[0];
  }

  // received видят все окна, opened и action только одно, иначе каждая вкладка перейдёт по route
  function notifyClients(event) {
    return self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function (list) {
      var targets = event.type === 'received' ? list : list.length ? [pickClient(list)] : [];
      targets.forEach(function (c) {
        c.postMessage({ type: 'raznos-notify-event', event: event });
      });
      return list;
    });
  }

  function record(type, payload, source, extra) {
    var event = { eventId: newId(), type: type, at: Date.now(), source: source, notification: payload };
    if (payload.messageId) event.messageId = payload.messageId;
    if (extra) Object.keys(extra).forEach(function (k) { event[k] = extra[k]; });
    return updateQueue(function (list) {
      list.push(event);
      return list.slice(-MAX_QUEUE);
    }).then(function () {
      return track(event)
        .catch(function () {})
        .then(function () {
          return notifyClients(event);
        })
        .then(function () {
          return event;
        });
    });
  }

  // показ + событие received, общий путь для push и локальных
  function display(payload, source) {
    // замена по messageId: старое показанное и отложенное снимаем до показа нового
    var replaced = payload.replaces ? cancelKeys([payload.replaces], true) : Promise.resolve();
    return replaced.then(function () {
      return displayNow(payload, source);
    });
  }

  function displayNow(payload, source) {
    // категория на лету: сохраняем до показа. Без явной category берём её id
    var def = payload.categoryDef && typeof payload.categoryDef.id === 'string' ? payload.categoryDef : null;
    var prepared = def ? upsertCategory(def) : Promise.resolve();
    return prepared.then(function () {
      return Promise.all([readJson(CATEGORIES, []), readJson(DISABLED, []), currentLocale()]).then(
        function (res) {
          // определение из payload берём напрямую: страница могла перезаписать набор между upsert и чтением
          var categories = def
            ? res[0]
                .filter(function (c) {
                  return c.id !== def.id;
                })
                .concat([def])
            : res[0];
          var category = payload.category || (def ? def.id : undefined);
          // отключённая в приложении категория: не показываем и не пишем received
          if (category && res[1].indexOf(category) >= 0) return;
          var shownPayload = category === payload.category ? payload : Object.assign({}, payload, { category: category });
          var options = buildOptions(shownPayload, source, categories, res[2]);
          var title = pick(payload.title_loc, res[2], payload.title);
          return self.registration.showNotification(title, options).then(function () {
            return record('received', shownPayload, source);
          });
        }
      );
    });
  }

  function handleClick(notification, actionId) {
    var data = notification.data || {};
    var payload = data.raznos;
    if (!payload) {
      notification.close();
      return Promise.resolve();
    }
    var source = data.source || 'local';
    return readJson(CATEGORIES, []).then(function (categories) {
      var def = actionId ? findAction(payload, categories, actionId) : undefined;
      // тап и reply (в вебе без текста) открывают приложение, у кнопки по умолчанию foreground
      var foreground = !actionId || !def || def.type === 'reply' || def.foreground !== false;
      notification.close();
      var extra = actionId ? { actionId: actionId, foreground: foreground } : undefined;
      var snooze = def && def.snoozeSec > 0 ? def.snoozeSec : 0;
      // повтор в общем хранилище, переживает остановку SW
      var saved = snooze ? addScheduled(payload, Date.now() + snooze * 1000, source) : Promise.resolve();
      return saved.then(function () {
        return record(actionId ? 'action' : 'opened', payload, source, extra).then(function () {
          if (!foreground) return;
          return self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function (list) {
            if (list.length > 0) return pickClient(list).focus();
            return self.clients.openWindow(safeRoute(payload.route));
          });
        });
      });
    });
  }

  // пользователь смахнул уведомление (программный close события не даёт)
  function handleClose(notification) {
    var data = notification.data || {};
    if (!data.raznos) return Promise.resolve();
    return record('dismissed', data.raznos, data.source || 'local');
  }

  // только путь своего origin: '//evil.example/x' тоже начинается со слэша
  function safeRoute(route) {
    if (typeof route !== 'string') return '/';
    try {
      return new URL(route, self.location.origin).origin === self.location.origin ? route : '/';
    } catch {
      return '/';
    }
  }

  function findNotification(key) {
    return self.registration.getNotifications({ tag: key }).then(function (list) {
      return list[0];
    });
  }

  function reply(event, data) {
    if (event.ports && event.ports[0]) event.ports[0].postMessage(data);
  }

  self.addEventListener('push', function (event) {
    if (!event.data) return;
    var payload;
    try {
      payload = event.data.json();
    } catch {
      payload = null;
    }
    // команда без title (cancel и/или config): ничего не показываем (кроме заглушки для Chrome)
    var isConfig = payload && payload.config && Array.isArray(payload.config.categories);
    if (payload && typeof payload.title !== 'string' && (Array.isArray(payload.cancel) || isConfig)) {
      var applied = isConfig
        ? updateCategories(function () {
            return payload.config.categories;
          })
        : Promise.resolve();
      event.waitUntil(
        applied
          .then(function () {
            return Array.isArray(payload.cancel) ? cancelKeys(payload.cancel, false) : 0;
          })
          .then(showSilentPlaceholder)
          .then(run)
      );
      return;
    }
    // битый payload всё равно показываем, иначе браузер выведет своё "сайт обновлён в фоне"
    if (!payload || typeof payload.title !== 'string') payload = { title: 'Новое уведомление' };
    if (!payload.id) payload.id = newId();
    event.waitUntil(display(payload, 'push').then(run));
  });

  self.addEventListener('activate', function (event) {
    event.waitUntil(run());
  });

  function onSync(event) {
    if (event.tag === FLUSH_TAG) event.waitUntil(run());
  }
  self.addEventListener('periodicsync', onSync);
  self.addEventListener('sync', onSync);

  self.addEventListener('notificationclick', function (event) {
    event.waitUntil(handleClick(event.notification, event.action || '').then(run));
  });

  self.addEventListener('pushsubscriptionchange', function (event) {
    event.waitUntil(onSubscriptionChange(event).then(run));
  });

  self.addEventListener('notificationclose', function (event) {
    event.waitUntil(handleClose(event.notification).then(run));
  });

  self.addEventListener('message', function (event) {
    var msg = event.data;
    if (!msg || typeof msg.type !== 'string') return;
    var job;
    if (msg.type === 'raznos-notify-ack') {
      var ids = msg.eventIds || [];
      job = updateQueue(function (list) {
        return list.filter(function (e) {
          return ids.indexOf(e.eventId) < 0;
        });
      });
    } else if (msg.type === 'raznos-notify-simulate-click') {
      job = findNotification(msg.key).then(function (n) {
        return n ? handleClick(n, msg.action || '') : undefined;
      });
    } else if (msg.type === 'raznos-notify-simulate-close') {
      job = findNotification(msg.key).then(function (n) {
        return n ? handleClose(n) : undefined;
      });
    } else if (msg.type === 'raznos-notify-tracking') {
      // настройку страница уже записала в хранилище, здесь заводим deviceId, накопленное досылает run
      job = ensureDeviceId().then(function () {
        trackFailures = 0;
      });
    } else if (msg.type === 'raznos-notify-show') {
      // локальный показ со страницы: единый путь сборки options и записи received
      job = display(msg.notification, 'local');
    } else if (msg.type === 'raznos-notify-schedule') {
      job = addScheduled(msg.notification, msg.at, 'local');
    } else if (msg.type === 'raznos-notify-cancel') {
      job = cancelKeys(msg.keys || [], false);
    } else if (msg.type === 'raznos-notify-register') {
      // конфиг registerUrl страница уже записала, здесь досылаем текущий токен
      job = onRegisterConfig();
    } else if (msg.type === 'raznos-notify-register-token') {
      job = enqueueRegister(msg.transport || 'webpush', msg.token);
    } else if (msg.type === 'raznos-notify-unregister') {
      job = enqueueUnregister(msg.transport, msg.token);
    } else if (msg.type === 'raznos-notify-clear-all') {
      job = Promise.all([
        self.registration.getNotifications().then(function (list) {
          list.forEach(function (n) {
            n.close();
          });
        }),
        updateScheduled(function () {
          return { list: [] };
        }),
      ]);
    } else if (msg.type === 'raznos-notify-flush') {
      job = flushDue();
    } else {
      return;
    }
    // держим SW ради ближайшей записи, ответ страницы от этого не зависит
    event.waitUntil(job.then(run, function () {}));
    var done = job.then(
      function () {
        reply(event, { ok: true });
      },
      function (e) {
        reply(event, { ok: false, error: String((e && e.message) || e) });
      }
    );
    event.waitUntil(done);
  });
})();
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="4f63f753-3c93-5671-9dff-cbecf33ca3a1")}catch(e){}}();
//# debugId=4f63f753-3c93-5671-9dff-cbecf33ca3a1
