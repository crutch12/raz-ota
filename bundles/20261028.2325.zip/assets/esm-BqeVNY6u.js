
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="0e4970e0-cfb9-5486-8f47-4c0938053c8c")}catch(e){}}();
const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DC7Zsi55.js","assets/dist-DG5JdDeT.js","assets/rolldown-runtime-hePW80VL.js"])))=>i.map(i=>d[i]);
import{s as e}from"./dist-DG5JdDeT.js";import{jt as t}from"./ionic-LSiiQzVr.js";var n=e(`SplashScreen`,{web:()=>t(()=>import(`./web-DC7Zsi55.js`).then(e=>new e.SplashScreenWeb),__vite__mapDeps([0,1,2]))});export{n as SplashScreen};
//# debugId=0e4970e0-cfb9-5486-8f47-4c0938053c8c
