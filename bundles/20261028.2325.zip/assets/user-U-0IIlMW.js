
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="e3858d9b-63c1-58c0-bed7-760c99dd020c")}catch(e){}}();
var e=e=>e?.claims.needsName===!0;function t(e){let t=e?.claims.firstName;return typeof t==`string`?t.trim():``}function n(e){return e?.name??e?.username??r(e?.phone)}function r(e){let t=/^\+7(\d{3})(\d{3})(\d{2})(\d{2})$/.exec(e??``);return t?`+7 ${t[1]} ${t[2]}-${t[3]}-${t[4]}`:e??``}export{t as i,e as n,n as r,r as t};
//# debugId=e3858d9b-63c1-58c0-bed7-760c99dd020c
