
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="695c9ac5-564b-5e98-a351-89c8834eaaf3")}catch(e){}}();
import{i as e}from"./dist-DG5JdDeT.js";var t=class extends e{async show(e){}async hide(e){}};export{t as SplashScreenWeb};
//# debugId=695c9ac5-564b-5e98-a351-89c8834eaaf3
