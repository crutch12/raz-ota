
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="519b98b9-1a15-5810-a61f-3466eb511616")}catch(e){}}();
import{It as e,V as t,tt as n}from"./vendor-BQNlu6Kq.js";var r=e();function i({label:e,onClick:i,testId:a,disabled:o=!1}){return(0,r.jsx)(n,{children:(0,r.jsx)(t,{size:`small`,disabled:o,onClick:i,"data-testid":a,children:e})})}export{i as t};
//# debugId=519b98b9-1a15-5810-a61f-3466eb511616
