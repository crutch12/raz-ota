
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="274b0c7f-0c82-5f86-a267-92407dbde8ac")}catch(e){}}();
const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DkMGIc0a.js","assets/dist-DG5JdDeT.js","assets/rolldown-runtime-hePW80VL.js"])))=>i.map(i=>d[i]);
import{s as e}from"./dist-DG5JdDeT.js";import{jt as t}from"./ionic-LSiiQzVr.js";import{t as n}from"./synapse-D5y-aojA.js";var r=e(`Geolocation`,{web:()=>t(()=>import(`./web-DkMGIc0a.js`).then(e=>new e.GeolocationWeb),__vite__mapDeps([0,1,2]))});n();export{r as Geolocation};
//# debugId=274b0c7f-0c82-5f86-a267-92407dbde8ac
