
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="d211ee82-e81c-5176-807b-06630153925a")}catch(e){}}();
import{i as e}from"./dist-DG5JdDeT.js";var t=class extends e{async canShare(){return typeof navigator>`u`||!navigator.share?{value:!1}:{value:!0}}async share(e){if(typeof navigator>`u`||!navigator.share)throw this.unavailable(`Share API not available in this browser`);return await navigator.share({title:e.title,text:e.text,url:e.url}),{}}};export{t as ShareWeb};
//# debugId=d211ee82-e81c-5176-807b-06630153925a
