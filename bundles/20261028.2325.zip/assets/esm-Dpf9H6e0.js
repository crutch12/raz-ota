
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="7f901593-3337-5620-b2d9-50664b9626ff")}catch(e){}}();
const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-W1pK95wN.js","assets/dist-DG5JdDeT.js","assets/rolldown-runtime-hePW80VL.js"])))=>i.map(i=>d[i]);
import{s as e}from"./dist-DG5JdDeT.js";import{jt as t}from"./ionic-LSiiQzVr.js";var n=e(`AppLauncher`,{web:()=>t(()=>import(`./web-W1pK95wN.js`).then(e=>new e.AppLauncherWeb),__vite__mapDeps([0,1,2]))});export{n as AppLauncher};
//# debugId=7f901593-3337-5620-b2d9-50664b9626ff
