
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="8790065a-a92b-582c-a08f-cc7610a694b8")}catch(e){}}();
function e(e){let t=!1,n=0;return{invalidate(){n++,t=!1},async run(r){if(t)return{status:`busy`};if(!e.online())return{status:`offline`};let i=n,a=e.scope(),o=()=>i===n&&a===e.scope();t=!0;try{let e=await r();return o()?{status:`success`,value:e}:{status:`stale`}}catch(e){return o()?{status:`error`,error:e}:{status:`stale`}}finally{i===n&&(t=!1)}}}}export{e as t};
//# debugId=8790065a-a92b-582c-a08f-cc7610a694b8
