
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="3da5227e-a62b-57d8-a743-c36faf5ed0b4")}catch(e){}}();
import{i as e}from"./dist-DG5JdDeT.js";var t=class extends e{async canOpenUrl(e){return{value:!0}}async openUrl(e){return window.open(e.url,`_blank`),{completed:!0}}};export{t as AppLauncherWeb};
//# debugId=3da5227e-a62b-57d8-a743-c36faf5ed0b4
