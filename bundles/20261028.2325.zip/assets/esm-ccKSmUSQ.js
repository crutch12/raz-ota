
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="4916b318-e6c7-5ae5-ad75-8bce07aabc82")}catch(e){}}();
const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DtRyHWo0.js","assets/dist-DG5JdDeT.js","assets/rolldown-runtime-hePW80VL.js"])))=>i.map(i=>d[i]);
import{s as e}from"./dist-DG5JdDeT.js";import{jt as t}from"./ionic-LSiiQzVr.js";var n=e(`Share`,{web:()=>t(()=>import(`./web-DtRyHWo0.js`).then(e=>new e.ShareWeb),__vite__mapDeps([0,1,2]))});export{n as Share};
//# debugId=4916b318-e6c7-5ae5-ad75-8bce07aabc82
