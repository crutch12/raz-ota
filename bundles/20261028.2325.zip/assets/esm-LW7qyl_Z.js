
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="7472b487-6c76-5248-a1f7-a9e9169bee8f")}catch(e){}}();
const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-C-ejJxOV.js","assets/dist-DG5JdDeT.js","assets/rolldown-runtime-hePW80VL.js"])))=>i.map(i=>d[i]);
import{n as e}from"./rolldown-runtime-hePW80VL.js";import{s as t}from"./dist-DG5JdDeT.js";import{jt as n}from"./ionic-LSiiQzVr.js";var r=e({App:()=>i}),i=t(`App`,{web:()=>n(()=>import(`./web-C-ejJxOV.js`).then(e=>new e.AppWeb),__vite__mapDeps([0,1,2]))});export{r as n,i as t};
//# debugId=7472b487-6c76-5248-a1f7-a9e9169bee8f
