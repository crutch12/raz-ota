
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="0100a8ea-c18d-5fa8-a706-b6d6d049aab2")}catch(e){}}();
import{s as e}from"./dist-DG5JdDeT.js";var t;(function(e){e.Dark=`DARK`,e.Light=`LIGHT`,e.Default=`DEFAULT`})(t||={});var n;(function(e){e.None=`NONE`,e.Slide=`SLIDE`,e.Fade=`FADE`})(n||={});var r=e(`StatusBar`);export{r as StatusBar,t as Style};
//# debugId=0100a8ea-c18d-5fa8-a706-b6d6d049aab2
