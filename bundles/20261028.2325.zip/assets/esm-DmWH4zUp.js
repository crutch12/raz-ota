
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="2ae14e59-2af5-51c1-82ec-56e44bebe072")}catch(e){}}();
import{s as e}from"./dist-DG5JdDeT.js";var t;(function(e){e.Dark=`DARK`,e.Light=`LIGHT`,e.Default=`DEFAULT`})(t||={});var n;(function(e){e.Body=`body`,e.Ionic=`ionic`,e.Native=`native`,e.None=`none`})(n||={});var r=e(`Keyboard`);export{r as Keyboard};
//# debugId=2ae14e59-2af5-51c1-82ec-56e44bebe072
