
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="3937873c-90f6-5ab1-8249-6a67445e29bf")}catch(e){}}();
var e=e=>new Promise(t=>setTimeout(t,e)),t=(t,n=0)=>e(t+Math.random()*n);function n(e,t,n){let r,i=new Promise(e=>{r=setTimeout(()=>e(n),t)});return Promise.race([e,i]).finally(()=>clearTimeout(r))}async function r(e,t){await n(e.catch(()=>void 0),t,void 0)}export{r as i,t as n,n as r,e as t};
//# debugId=3937873c-90f6-5ab1-8249-6a67445e29bf
