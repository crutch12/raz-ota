
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="0dc9264b-eaf5-51ce-a234-f1a626c24ac2")}catch(e){}}();
var e=[`error`,`breadcrumb`,`span`,`event`,`screen`,`identify`],t=()=>({name:`console`,handles:new Set(e),async init(){},send(e){console.debug(`[telemetry]`,e.kind,e)},async setConsent(){},async flush(){},async shutdown(){}});export{t as default};
//# debugId=0dc9264b-eaf5-51ce-a234-f1a626c24ac2
