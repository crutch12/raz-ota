
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="21cefd7e-c6e5-558b-a0b0-ebd361493499")}catch(e){}}();
const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CYAVPlXJ.js","assets/dist-DG5JdDeT.js","assets/rolldown-runtime-hePW80VL.js"])))=>i.map(i=>d[i]);
import{n as e}from"./rolldown-runtime-hePW80VL.js";import{s as t}from"./dist-DG5JdDeT.js";import{jt as n}from"./ionic-LSiiQzVr.js";var r=e({Preferences:()=>i}),i=t(`Preferences`,{web:()=>n(()=>import(`./web-CYAVPlXJ.js`).then(e=>new e.PreferencesWeb),__vite__mapDeps([0,1,2]))});export{r as n,i as t};
//# debugId=21cefd7e-c6e5-558b-a0b0-ebd361493499
