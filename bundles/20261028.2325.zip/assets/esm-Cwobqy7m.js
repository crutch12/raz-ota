
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="73208bbc-c164-5f5a-aed1-b87945b50e3d")}catch(e){}}();
const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DxGeXfti.js","assets/dist-DG5JdDeT.js","assets/rolldown-runtime-hePW80VL.js"])))=>i.map(i=>d[i]);
import{s as e}from"./dist-DG5JdDeT.js";import{jt as t}from"./ionic-LSiiQzVr.js";var n=e(`Network`,{web:()=>t(()=>import(`./web-DxGeXfti.js`).then(e=>new e.NetworkWeb),__vite__mapDeps([0,1,2]))});export{n as Network};
//# debugId=73208bbc-c164-5f5a-aed1-b87945b50e3d
